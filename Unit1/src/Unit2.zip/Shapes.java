//Dean Mason
//Unit 2

/**
 * A standalone file for the enum so that it can be accessed everywhere without dot operator
 * @author Dean Mason
 * @version 2.0
 */
public enum Shapes {OVAL, LINE, BOX}