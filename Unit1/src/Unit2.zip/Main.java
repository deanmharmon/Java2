//Dean Mason
//Unit 2

/**
 * Main function, just instantiates Frame
 * @author Dean Mason
 * @version 2.0
 */
public class Main {
    public static void main(String[] args) {
        new Frame();
    }
}